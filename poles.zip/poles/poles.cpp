/* ----------------------------------------------------------------
 * Copyright (c) 2008, TDT LLC
 * David L. Page, PhD
 * davidpage@ieee.org
 * ----------------------------------------------------------------*/

#include "poles.h"

#define MIN(a,b) ((a < b) ? a : b)

/* ----------------------------------------------------------------*/
LONG WINAPI MainWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	/* int w,h; */
	static Poles *poles;

	SetLastError(0);
	switch (uMsg)
	{
		case WM_CREATE:
		{
			PIXELFORMATDESCRIPTOR pfd;
			PIXELFORMATDESCRIPTOR *ppfd = NULL;

			poles = (Poles *)(((LPCREATESTRUCT)lParam)->lpCreateParams);
			poles->m_Hdc = GetDC(hWnd);
			poles->m_Hwnd = hWnd;
			if (poles->pixelFormat <= 0)
			{
				poles->pixelFormat = 11; // Some arbitrary default
			}
			else
			{
				ppfd = &pfd;
				DescribePixelFormat(
					(HDC)poles->m_Hdc,
					poles->pixelFormat,
					sizeof(PIXELFORMATDESCRIPTOR),
					ppfd);
			}
			SetPixelFormat(poles->m_Hdc, poles->pixelFormat, ppfd);
		}
		break;
		case WM_CHAR:
			poles->Keyboard((unsigned char)wParam);
		break;
		case WM_KEYDOWN:
			if (lParam & 0x1000000)
			{
				poles->SpecialKey((int)wParam);
			}
		break;
		case WM_CLOSE:
			poles->running = 0;
			poles->idle = 0;
		break;
		default:
			return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	DWORD error = GetLastError();
	if (error > 0)
	{
		DebugBreak();
	}
	return 0;
}

DWORD WINAPI createWindow(LPVOID args)
{
	Poles *poles = (Poles *)args;
	HINSTANCE hinstance;
	WNDCLASS  wc;
	DWORD window_style;
	MSG msg;

	HANDLE windowCreated = OpenEvent(EVENT_ALL_ACCESS, FALSE,
		TEXT("windowCreated"));

	hinstance = GetModuleHandle(NULL);
	if (!hinstance)
	{
		std::cout << "Couldn't get a handle to my module.";
		return FALSE;
	}

	if (!GetClassInfo(hinstance, TEXT("SMFoLD_Window"), &wc))
	{
		wc.style = CS_OWNDC;
		wc.lpfnWndProc = (WNDPROC)MainWndProc;
		wc.cbClsExtra = 0;
		wc.cbWndExtra = 0;
		wc.hInstance = hinstance;
		wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
		wc.hCursor = LoadCursor(NULL, IDC_ARROW);
		wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
		wc.lpszMenuName = NULL;
		wc.lpszClassName = TEXT("SMFoLD_Window");

		if (!RegisterClass(&wc))
		{
			std::cout << "Couldn't register window class";
		}
	}

	window_style = WS_VISIBLE | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX;

	poles->m_Hwnd = CreateWindow(TEXT("SMFoLD_Window"),
		TEXT("Spinning Poles"),
		window_style,
		poles->x, poles->y,
		poles->width,
		poles->height,
		NULL, NULL, hinstance, poles);

	if (!poles->m_Hwnd)
	{
		std::cout << "Render SPU: Create Window failed! That's almost certainly terrible.";
	}

	SetEvent(windowCreated);
	CloseHandle(windowCreated);
	while (GetMessage(&msg, NULL, 0, 0))
	{
		if (msg.hwnd == poles->m_Hwnd)
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	poles->m_Hwnd = NULL;
	poles->m_Hdc = 0;
	return 0;
}

/*****************************************************************************/
void Poles::Init(void)
{
	// Initialize the OpenGL environment
	// Create the context
	m_Hglrc = wglCreateContext(m_Hdc);

	DWORD error = GetLastError();
	if (error)
	{
		DebugBreak();
	}

	wglMakeCurrent(m_Hdc, m_Hglrc);

	Anim = TRUE;

	glClearColor(0, 0, 0, 0);
	if (background_flag)
	{
		glClearColor(0.25, 0.4, 0.95, 0.0);
	}

	glShadeModel(GL_SMOOTH);

	glEnable(GL_DEPTH_TEST);

	glViewport(0, 0, (GLsizei)width, (GLsizei)height);
	glPolygonMode(GL_FRONT, GL_FILL);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	// Perspective view
	const GLfloat perspective[16] = {
		2.799038, 0.000000, 0.000000, 0.000000,
		0.000000, 3.732051, 0.000000, 0.000000,
		0.000000, 0.000000, -1.907782, -1.000000,
		0.000000, 0.000000, -1.577181, 0.000000 };
	glMultMatrixf(perspective);

	// Eye point
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	const GLfloat eye[16] = {
		1.000000, 0.000000, 0.000000, 0.000000,
		0.000000, 1.000000, 0.000000, 0.000000,
		0.000000, 0.000000, 1.000000, 0.000000,
		0.000000, 0.000000, 0.000000, 1.000000 };
	glMultMatrixf(eye);
	glTranslatef(0.000000, 0.000000, -0.914400);

	error = glGetError();
	if (error)
	{
		DebugBreak();
	}

// For Windows...
#if 0
// This section is not needed for SMFoLD since the application is linked to
// the SMFoLD source process library which exports these functions directly.
// To run the application as a stand alone application change the 0 to a 1
// and link to the system OpenGL library.

	// Get the OpenGL function pointers to the functions not directly exported by
	// the Windows OpenGL.dll
	// First, VBO functions
	glGenBuffers = (PFNGLGENBUFFERSPROC)wglGetProcAddress("glGenBuffers");
	glBindBuffer = (PFNGLBINDBUFFERPROC)wglGetProcAddress("glBindBuffer");
	glBufferData = (PFNGLBUFFERDATAPROC)wglGetProcAddress("glBufferData");
	glBufferSubData = (PFNGLBUFFERSUBDATAPROC)wglGetProcAddress("glBufferSubData");
	glDeleteBuffers = (PFNGLDELETEBUFFERSPROC)wglGetProcAddress("glDeleteBuffers");
	glGetBufferParameteriv = (PFNGLGETBUFFERPARAMETERIVPROC)wglGetProcAddress("glGetBufferParameteriv");
	glMapBuffer = (PFNGLMAPBUFFERPROC)wglGetProcAddress("glMapBuffer");
	glUnmapBuffer = (PFNGLUNMAPBUFFERPROC)wglGetProcAddress("glUnmapBuffer");

	// Next, shader related functions
	glUseProgram = (PFNGLUSEPROGRAMPROC)wglGetProcAddress("glUseProgram");
	glGetProgramiv = (PFNGLGETPROGRAMIVPROC)wglGetProcAddress("glGetProgramiv");
	glLinkProgram = (PFNGLLINKPROGRAMPROC)wglGetProcAddress("glLinkProgram");
	glAttachShader = (PFNGLATTACHSHADERPROC)wglGetProcAddress("glAttachShader");
	glDetachShader = (PFNGLDETACHSHADERPROC)wglGetProcAddress("glDetachShader");
	glCreateProgram = (PFNGLCREATEPROGRAMPROC)wglGetProcAddress("glCreateProgram");
	glDeleteProgram = (PFNGLDELETEPROGRAMPROC)wglGetProcAddress("glDeleteProgram");
	glGetShaderInfoLog = (PFNGLGETSHADERINFOLOGPROC)wglGetProcAddress("glGetShaderInfoLog");
	glGetShaderiv = (PFNGLGETSHADERIVPROC)wglGetProcAddress("glGetShaderiv");
	glCompileShader = (PFNGLCOMPILESHADERPROC)wglGetProcAddress("glCompileShader");
	glShaderSource = (PFNGLSHADERSOURCEPROC)wglGetProcAddress("glShaderSource");
	glCreateShader = (PFNGLCREATESHADERPROC)wglGetProcAddress("glCreateShader");
	glDeleteShader = (PFNGLDELETESHADERPROC)wglGetProcAddress("glDeleteShader");
	glGetProgramInfoLog = (PFNGLGETPROGRAMINFOLOGPROC)wglGetProcAddress("glGetProgramInfoLog");
	glUseProgram = (PFNGLUSEPROGRAMPROC)wglGetProcAddress("glUseProgram");
	glGetUniformLocation = (PFNGLGETUNIFORMLOCATIONPROC)wglGetProcAddress("glGetUniformLocation");
	glGetUniformfv = (PFNGLGETUNIFORMFVPROC)wglGetProcAddress("glGetUniformfv");
	glGetUniformfv = (PFNGLGETUNIFORMFVPROC)wglGetProcAddress("glGetUniformfv");
	glUniform4fv = (PFNGLUNIFORM4FVPROC)wglGetProcAddress("glUniform4fv");
	glUniform1f = (PFNGLUNIFORM1FPROC)wglGetProcAddress("glUniform1f");
	glUniform4f = (PFNGLUNIFORM4FPROC)wglGetProcAddress("glUniform4f");
#endif
	// Create vertex buffer objects. They will need to be deleted when the program exits
	// Put the verticies and normals in the same buffer object.
	// Calling glBufferData() with  a NULL pointer only reserves memory.
	// Copy actual data with 2 calls of glBufferSubDataARB, one for vertex coords and one for normals.
	// target flag is GL_ARRAY_BUFFER_ARB, and usage flag is GL_STATIC_DRAW_ARB
	glGenBuffers(1, &vboId);
	glBindBuffer(GL_ARRAY_BUFFER, vboId);
	glBufferData(GL_ARRAY_BUFFER, sizeof(cylinder) + sizeof(cylNormals) + sizeof(endCaps), 0, GL_STATIC_DRAW);

	// copy vertices starting from 0 offest
	glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(cylinder), cylinder);
	// copy normals after vertices
	glBufferSubData(GL_ARRAY_BUFFER, sizeof(cylinder), sizeof(cylNormals), cylNormals);
	// copy end caps after vertices
	glBufferSubData(GL_ARRAY_BUFFER, sizeof(cylinder) + sizeof(cylNormals), sizeof(endCaps), endCaps);

	SetMode(ALL_MODE);
	running = 1;
	idle = 0;

	CreateShaders();
}

void Poles::CreateShaders()
{
	GLint status;

	// Vertex shader
	vertShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertShader, 1,
		(const GLchar **)vertProgramText, NULL);
	glCompileShader(vertShader);
	glGetShaderiv(vertShader, GL_COMPILE_STATUS, &status);
	if (!status)
	{
		GLint length;
		GLchar *log;
		glGetShaderiv(vertShader, GL_INFO_LOG_LENGTH, &length);
		log = new GLchar[length];
		glGetShaderInfoLog(vertShader, length, &length, log);
		std::cout << "Vertex shader compile log = \n" << log << "\n";
	}

	/*
	* Fragment shader
	*/

	fragShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragShader, 1,
		(const GLchar **)fragProgramText, NULL);
	glCompileShader(fragShader);
	glGetShaderiv(fragShader, GL_COMPILE_STATUS, &status);
	if (!status)
	{
		GLint length;
		GLchar *log;
		glGetShaderiv(fragShader, GL_INFO_LOG_LENGTH, &length);
		log = new GLchar[length];
		glGetShaderInfoLog(fragShader, length, &length, log);
		std::cout << "Fragment shader compile log =\n" << log << "\n";
	}

	VertProg = glCreateProgram();

	glAttachShader(VertProg, vertShader);
	glAttachShader(VertProg, fragShader);
	glLinkProgram(VertProg);
	glGetProgramiv(VertProg, GL_LINK_STATUS, &status);
	if (!status)
	{
		GLint length;
		GLchar *log;
		glGetProgramiv(VertProg, GL_INFO_LOG_LENGTH, &length);
		log = (GLchar *)calloc(length, sizeof(GLchar));
		glGetProgramInfoLog(VertProg, length, &length, log);
		printf("Fragment program link log =\n%s\n", log);
		free(log);
	}
	glUseProgram(VertProg);
	lightPos = glGetUniformLocation(VertProg, (const GLubyte *)"LightPos");
	diffuse = glGetUniformLocation(VertProg, (const GLubyte *)"Diffuse");
	specular = glGetUniformLocation(VertProg, (const GLubyte *)"Specular");
	CameraSpacing = glGetUniformLocation(VertProg, (const GLubyte *)"cameraAngle");
	glUniform4fv(lightPos, 1, light_position);
	glUniform4fv(diffuse, 1, mat_shininess);
	glUniform4fv(specular, 1, mat_specular);

}

/* ----------------------------------------------------------------*/
void Poles::DrawPoles( void )
{
	glPushMatrix();

	if (Anim)
	{
		glRotatef(day, 1, 0, 0);
	}
	if (wiggle_flag)
	{
		glRotatef(0.025*(fabs(180 - year) - 90), 0, 1, 0);
	}

//	glRotatef(0, 1, 0, 0);

	// The cylinders ar built out of rings. The glTranslatef() function moves to
	// the next ring. The ring is drawn again at the new location.

	// bind VBOs with IDs and set the buffer offsets of the bound VBOs
	// When buffer object is bound with its ID, all pointers in gl*Pointer()
	// are treated as offset instead of real pointer.
	glBindBuffer(GL_ARRAY_BUFFER, vboId);

	// enable vertex arrays
	glEnableClientState(GL_VERTEX_ARRAY);

	glScalef(scale_factor, scale_factor, scale_factor);
	glNormal3f(0.0f, 0.0f, 1.0f);
	glUniform1f(CameraSpacing, spacing);

	int nElements = sizeof(cylinder) / sizeof(GLfloat) / 3;
	for (int i = 0; i < 4; ++i)
	{
		glPushMatrix();
		switch (i)
		{
			case 0:
				glUniform4f(diffuse, .2, .4, .2, 0);
				glUniform4f(specular, .2, .4, .2, 0);
			break;
			case 1:
				glUniform4f(diffuse, .4, .2, .2, 0);
				glUniform4f(specular, .4, .2, .2, 0);
				break;
			case 2:
				glUniform4f(diffuse, .2, .2, .4, 0);
				glUniform4f(specular, .2, .2, .4, 0);
				break;
			case 3:
				glUniform4f(diffuse, .4, .4, .2, 0);
				glUniform4f(specular, .4, .4, .2, 0);
				break;
		}

		glEnableClientState(GL_NORMAL_ARRAY);
		for (int j = 0; j < 32; ++j)
		{
			glNormalPointer(GL_FLOAT, 0, (void*)sizeof(cylinder));
			glVertexPointer(3, GL_FLOAT, 0, BUFFER_OFFSET(0));

			glDrawArrays(GL_QUAD_STRIP, 0, nElements);
			glTranslatef(0.0, 0.0, 0.00218);
		}
		// We don't use the normals array for the endcaps
		glDisableClientState(GL_NORMAL_ARRAY);

		// Draw the end cap. The end cap is made up of a triangle fan and four
		// quad strips.
		size_t bufferOffset = sizeof(cylinder) + sizeof(cylNormals);
		glVertexPointer(3, GL_FLOAT, 0, BUFFER_OFFSET(bufferOffset));
		glDrawArrays(GL_TRIANGLE_FAN, 0, 34);
		bufferOffset = sizeof(cylinder) + sizeof(cylNormals) + 34 * sizeof(GLfloat) * 3;
		for (int i = 0; i < 4; i++)
		{
			glVertexPointer(3, GL_FLOAT, 0, BUFFER_OFFSET(bufferOffset));
			glDrawArrays(GL_QUAD_STRIP, 0, 66);
			bufferOffset += 66 * sizeof(GLfloat) * 3;
		}
		glPopMatrix();

		// Rotate 90 degrees about x to draw another cylinder.
		glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
	}

	glDisableClientState(GL_VERTEX_ARRAY);  // disable vertex arrays

											// it is good idea to release VBOs with ID 0 after use.
	// Once bound with 0, all pointers in gl*Pointer() behave as real
	// pointer, so, normal vertex array operations are re-activated
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glPopMatrix();

}

/* ----------------------------------------------------------------*/
void Poles::Display(void)
{
	glClearColor(background[0],	background[1], background[2],
		background[3]);

	glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glPushMatrix();

	glRotatef(Xrot, 1, 0, 0);
	glRotatef(Yrot, 0, 1, 0);
	glRotatef(Zrot, 0, 0, 1);

	switch( mode )
	{
		case ALL_MODE:
		case CORNERS_MODE:
			glPushMatrix();
			glTranslatef( -0.15,  0.075, 0.0 );
			DrawPoles();
			glTranslatef(  0.3, -0.15, 0.0 );
			DrawPoles();
			glPopMatrix();
			/* fall through */
		case THREE_MODE:
			glPushMatrix();
			glTranslatef( -0.075, -0.05, 0.0 );
			DrawPoles();
			glTranslatef(  0.15,  0.10, 0.0 );
			DrawPoles();
			glPopMatrix();
			/* fall through */
		case ONE_MODE:
			DrawPoles();
	}

	glPopMatrix();

	if (Anim)
	{
		static GLint T0 = 0;
		static GLint T1 = 0;
		static GLint Frames = 0;
		T0 = clock();
		Frames++;
		if (T0 - T1 >= 5000)
		{
			GLfloat seconds = (T0 - T1) / 1000.0;
			GLfloat fps = Frames / seconds;
			std::cout << Frames << " frames in " << seconds << " seconds = " << fps << " FPS\n";
			T1 = T0;
			Frames = 0;
		}
	}

	wglSwapLayerBuffers(m_Hdc, WGL_SWAP_MAIN_PLANE);

//	SMFoLD_SwapBuffers();
}

/* ----------------------------------------------------------------*/
void Poles::Idle(void)
{
	int time = clock();

	year = (time - StartTime) / 60.0 / speed_factor / 0.02;
	year -= (floor( year / 360.0 ) * 360.0);

	day = (float)(time - StartTime) / 60.0 / speed_factor;
	day -= (floor( day / 360.0 ) * 360.0);

	Display();
}

void Poles::SetMode(int m)
{
	if (m > MAX_MODE)
	{
		m = MIN_MODE;
	}
	mode = m;
	SetLastError(0);
	std::cout << "Cycling display modes (up):   mode = " << mode << "\n";
	DWORD error = GetLastError();
	if (error)
	{
		SetLastError(0);
		//		DebugBreak();
	}
}

/* ----------------------------------------------------------------*/
void Poles::Keyboard (unsigned char key)
{
	switch (key) 
	{
		case 'a':
			Anim = !Anim;
			//StartRot = Yrot;
			StartTime = clock();
			break;
		case 'w':
			// Changing the width causes the data to be updated in the VBO
			width_factor += width_step;
			if (width_factor > width_max )
			{
				width_factor = width_min;
			}
			break;
		case 'b':
			background_flag = !background_flag;
			if (background_flag)
			{
				background[0] = 0.5;
				background[1] = 0.5;
				background[2] = 0.5;
				background[3] = 0.5;
			}
			else
			{
				background[0] = 0.0;
				background[1] = 0.0;
				background[2] = 0.0;
				background[3] = 0.0;
			}
			break;
		case 'z':
			// Changing the length causes the data to be updated in the VBO
			z_length_factor += 0.25;
			if (z_length_factor > zmax )
			{
				z_length_factor = 0.25;
			}
			break;
		case 'g':
			wiggle_flag= !wiggle_flag;
			break;
			break;
		case 'm':
			++mode;
			SetMode(mode);
		break;
		case 's':
			scale_factor += 0.25;
			if (scale_factor > zmax)
			{
				scale_factor = 0.25;
			}
		break;
		case '0':
			Xrot = 0.0;
			Yrot = 0.0;
			Zrot = 0.0;
			spacing = 0.0;
		break;
		case 27:
			running = 0;
			break;
		default:
			break;
	}
	if (!Anim)
	{
		idle = 1;
	}
}

/* ----------------------------------------------------------------*/
void Poles::SpecialKey(int key)
{
	float step = 0.1;

	switch (key)
	{
		case VK_UP:
			if (Xrot < 90)
			{
				Xrot += 10 * step;
			}
		break;
		case VK_DOWN:
			if (Xrot > -90)
			{
				Xrot -= 10 * step;
			}
		break;
		case VK_PRIOR:
			if (Zrot < 90)
			{
				Zrot += 10 * step;
			}
		break;
		case VK_LEFT:
			if (Yrot > -90)
			{
				Yrot -= 10 * step;
			}
		break;
		case VK_NEXT:
			if (Zrot > -90)
			{
				Zrot -= 10 * step;
			}
		break;
		case VK_RIGHT:
			if (Yrot < 90)
			{
				Yrot += 10 * step;
			}
		break;
		case VK_HOME:
			if (spacing < .5)
			{
				spacing += .025;
			}
		break;
		case VK_END:
			if (spacing > 0)
			{
				spacing -= .025;
			}
		break;
	}

	if (!Anim)
	{
		idle = 1;
	}
}

/* ----------------------------------------------------------------*/
int main(int argc, char** argv)
{
//	static int first = 1;
//	while (first);
	SetLastError(0);
	Poles *poles = new(Poles);

	// Create thread for managing the window
	HANDLE windowCreated = CreateEvent(NULL, TRUE, FALSE, TEXT("windowCreated"));

	std::thread t1(createWindow, (void *)poles);
	t1.detach();
	if (WaitForSingleObject(windowCreated, INFINITE) == WAIT_TIMEOUT)
	{
		std::cout << "Failed to create window";
		exit(0);
	}

	CloseHandle(windowCreated);
	DWORD error = GetLastError();
	if (error)
	{
		DebugBreak();
	}

	poles->Init();

	error = glGetError();
	if (error)
	{
		DebugBreak();
	}

	while (poles->running)
	{
		if (poles->Anim || poles->idle)
		{
			poles->Idle();
			poles->idle = 0;
		}
	}
	return 0;
}

/* EOF */
/* ----------------------------------------------------------------*/
