#pragma once

static const char *vertProgramText[] = {
	"#version 120\n"
#include "SMFoLD_Geometry.fxh"
	"\n"
	"void main()\n"
	"{\n"
	"	gl_Position = ftransform();\n"
	"	vec3 norms = gl_NormalMatrix * gl_Normal;\n"
	"	gl_TexCoord[0].x = norms.x;\n"
	"	gl_TexCoord[0].y = norms.y;\n"
	"	gl_TexCoord[0].z = norms.z;\n"
	"	gl_TexCoord[0].w = 1.0;\n"
	"	gl_Position = SMFoLD_Shift(gl_Position);\n"
	"}\n"
};

static const char *fragProgramText[] = {
	"#version 120\n"
	"\n"
	"uniform vec4 LightPos;\n"
	"uniform vec4 Specular;\n"
	"uniform vec4 Diffuse;\n"
	"\n"
	"void main()\n"
	"{\n"
	"	float x = dot(vec3(LightPos), vec3(LightPos));\n"
	"	float y = inversesqrt(x);\n"
	"	float z;\n"
	"	vec4 lightDir = LightPos * y;\n"
	"\n"
	"	x = dot(vec3(gl_TexCoord[0]), vec3(lightDir));\n"
	"	vec4 diffuseColor = Diffuse * x;\n"
	"	x = pow(x, 2);\n"
	"	vec4 specularColor = Specular * x;\n"
	"	gl_FragColor = diffuseColor + specularColor;\n"
	"}\n"
};
