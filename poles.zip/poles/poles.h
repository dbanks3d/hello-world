#pragma once

#include "windows.h"
#include "SMFoLD_Prototypes.h"
//#include "GL/glew.h"
//#include "GL/glext.h"
#include "GL/gl.h"
#include <thread>
#include <iostream>

#include "vertices.h"
#include "ShaderSource.h"

enum mode_type
{
	MIN_MODE = 0,
	ONE_MODE = 0,
	THREE_MODE,
	CORNERS_MODE,
	ALL_MODE,
	MAX_MODE = ALL_MODE
};

#define BUFFER_OFFSET(i) ((void *)(i))

class Poles
{
public:
	Poles(void) {};
	~Poles() {};
	HWND m_Hwnd;
	HDC m_Hdc;
	HGLRC m_Hglrc;
	int pixelFormat;
	int x = 100;
	int y = 100;
	int width = 1280;
	int height = 800;
	int running;
	int idle;
	GLboolean Anim = GL_TRUE;

	void Init(void);
	void Display(void);
	void Keyboard(unsigned char key);
	void SpecialKey(int key);
	void Idle(void);
	//	void Init(void);

private:
	float year = 0, day = 0;
	GLfloat Xrot = 0, Yrot = 0, Zrot = 0;
	GLfloat spacing = 0;
	GLfloat zmax = 2.0;
	int StartTime = 0;
	GLfloat StartRot = 0;
	float speed_factor = 1.0 / 2.0;
	int mode = ALL_MODE;

	float z_length_factor = 1.0f;
	float scale_factor = 1.0f;
	float width_min = 0.004375; // 0.0175/4;
	float width_max = 0.07; // 4.0*0.0175;
	float width_factor = 0.0175;
	float width_step = 0.008203125;

	float z_near_plane = 0.5424;
	float z_far_plane = 1.7374;
	float z_screen = 0.9144;
	GLclampf background[4] = { 0.0, 0.0, 0.0, 0.0 };
	
	GLboolean background_flag = GL_FALSE;
	GLboolean wiggle_flag = GL_FALSE;

	float pi = 3.14159256535;

	int loopcount;

	GLuint VertProg;
	GLuint vertShader;
	GLuint fragShader;
	GLfloat mat_specular[4] = { .1, 1, .1, 1 };
	GLfloat mat_shininess[4] = { .1, 1, .1, 1 };
	GLfloat light_position[4] = { 0.0, 0.0, 5.0, 1.0 };
	GLuint lightPos;
	GLuint specular;
	GLuint diffuse;
	GLuint CameraSpacing;

	void CreateShaders(void);
	void DrawPoles(void);
	void SetMode(int mode = 0);

// For Windows
#if 0
	/* OpenGL function pointers */
	PFNGLGENBUFFERSPROC p_glGenBuffers;                     // VBO Name Generation Procedure
	PFNGLBINDBUFFERPROC p_glBindBuffer;                     // VBO Bind Procedure
	PFNGLBUFFERDATAPROC p_glBufferData;                     // VBO Data Loading Procedure
	PFNGLBUFFERSUBDATAPROC p_glBufferSubData;               // VBO Sub Data Loading Procedure
	PFNGLDELETEBUFFERSPROC p_glDeleteBuffers;               // VBO Deletion Procedure
	PFNGLGETBUFFERPARAMETERIVPROC p_glGetBufferParameteriv; // return various parameters of VBO
	PFNGLMAPBUFFERPROC p_glMapBuffer;                       // map VBO procedure
	PFNGLUNMAPBUFFERPROC p_glUnmapBuffer;                   // unmap VBO procedure

	PFNGLATTACHSHADERPROC p_glAttachShader;
	PFNGLDETACHSHADERPROC p_glDetachShader;
	PFNGLGETPROGRAMIVPROC p_glGetProgramiv;
	PFNGLLINKPROGRAMPROC p_glLinkProgram;
	PFNGLCREATEPROGRAMPROC p_glCreateProgram;
	PFNGLGETSHADERINFOLOGPROC p_glGetShaderInfoLog;
	PFNGLGETSHADERIVPROC p_glGetShaderiv;
	PFNGLCOMPILESHADERPROC p_glCompileShader;
	PFNGLSHADERSOURCEPROC p_glShaderSource;
	PFNGLCREATESHADERPROC p_glCreateShader;
	PFNGLGETPROGRAMINFOLOGPROC p_glGetProgramInfoLog;
	PFNGLUSEPROGRAMPROC p_glUseProgram;
	PFNGLGETUNIFORMLOCATIONPROC p_glGetUniformLocation;
	PFNGLGETUNIFORMFVPROC p_glGetUniformfv;
	PFNGLUNIFORM4FVPROC p_glUniform4fv;
	PFNGLDELETEPROGRAMPROC p_glDeleteProgram;
	PFNGLDELETESHADERPROC p_glDeleteShader;
	PFNGLUNIFORM1FPROC p_glUniform1f;
	PFNGLUNIFORM4FPROC p_glUniform4f;
#endif

	GLuint vboId;
};